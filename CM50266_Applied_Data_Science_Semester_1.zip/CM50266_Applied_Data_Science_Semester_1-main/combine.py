import os

def combine_csv_files(directory_path, output_file):
    csv_files = [file for file in os.listdir(directory_path) if file.endswith(".csv")]

    if not csv_files:
        print("No CSV files found in the directory.")
        return

    combined_data = []

    for file_name in csv_files:
        file_path = os.path.join(directory_path, file_name)
        with open(file_path, 'r') as file:
            lines = file.readlines()
            combined_data.extend(lines)

    with open(output_file, 'w') as output:
        output.writelines(combined_data)
    print(f"Combined CSV files saved to {output_file}")


combine_csv_files('csv_data_2022', 'combined_2022_output.csv')
combine_csv_files('csv_data_2023', 'combined_2023_output.csv')

