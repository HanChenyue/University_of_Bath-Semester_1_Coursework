import os


def combine_csv_files(directory_path, output_file):
    csv_files = [file for file in os.listdir(directory_path) if file.endswith(".csv")]

    if not csv_files:
        return print("Error! No CSV files found in the directory:", directory_path)

    combined_data = []

    for file_name in csv_files:
        file_path = os.path.join(directory_path, file_name)
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
                combined_data.extend(lines)
                print(f"Succesfully processed file: {file_path}")
        except UnicodeDecodeError:
            print(f"Error processing file: {file_path}")
            print("Terminating program, please manually clean up the problematic file and re-run this program.")
            break

    with open(output_file, 'w', encoding='utf-8') as output:
        output.writelines(combined_data)
    print(f"Combined CSV files saved to {output_file}")


combine_csv_files('csv_data_2022', 'combined_2022_output.csv')
combine_csv_files('csv_data_2023', 'combined_2023_output.csv')
combine_csv_files('/home/hcne/MSc_Semester_1/CM50266_Applied_Data_Science', 'combined_2022_and_2023_output.csv')